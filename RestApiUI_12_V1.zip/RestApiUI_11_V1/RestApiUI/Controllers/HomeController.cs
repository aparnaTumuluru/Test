﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.IdentityModel.Protocols;
using Newtonsoft.Json;
using RestApiUI.Models;
using Workbench.Client;
using Workbench.Client.Extensions;
using Workbench.Client.Models;

namespace RestApiUI.Controllers
{
	
	public class HomeController : Controller
	{

		string aadInstance = "https://login.windows.net/{0}";
		string tenant = "infy615372outlook.onmicrosoft.com";
		string clientId = "fa0a8340-7a8a-4d17-99e8-ddae1cda04ae";
		Uri redirectUri = new Uri("https://wb-urlp-api.azurewebsites.net/");
		string appKey = "CelymHYHvss7sZhpx/3qtzRwE5yaf+KnqACc/tab+Yc=";
		string apiResourceId = "fa0a8340-7a8a-4d17-99e8-ddae1cda04ae";
		string apiBaseAddress = "https://wb-urlp-api.azurewebsites.net/";
		AuthenticationContext authContext = null;
		string authority;
		ClientCredential clientCredential;


		public async Task<IActionResult> Index()
		{
			AADAuthentication();
			ViewBag.CurrentUser = await GatewayApi.Instance.GetCurrentUserDetails();
			//TODo: get the User name based on all mapping in from all user details. 

			return View();
		}

		private void AADAuthentication()
		{
			authority = String.Format(aadInstance, tenant);
			clientCredential = new ClientCredential(clientId, appKey);
			GatewayApi.AuthToken = GetAccesstoken();
			GatewayApi.SiteUrl = apiBaseAddress;
		}

		public async Task<bool> CreateInvoice()
		{
			AADAuthentication();
			ActionInformation AInfo  = new ActionInformation();
			WorkflowActionParameter wfParam = new WorkflowActionParameter();
			wfParam.Name = "TestName";
			wfParam.Value = "TestValue";
			AInfo.WorkflowActionParameters.Add(wfParam);
			AInfo.WorkflowFunctionId = 1;
			
			//To be tested
			string res = await GatewayApi.Instance.CreateNewContractAsync(AInfo, "1","1","1");
			return res==string.Empty;
		}

		public IActionResult About()
		{
			ViewData["Message"] = "Your application description page.";

			return View();
		}

		public IActionResult Contact()
		{
			ViewData["Message"] = "Your contact page.";

			return View();
		}

		public async Task< IActionResult> Users()
		{
			AADAuthentication();
			ViewBag.UsersList = await GatewayApi.Instance.GetAllUsersAsync();
			return View();
		}
		public async Task<IActionResult> Applications()
		{
			AADAuthentication();
			ViewBag.ApplicationsList = await GatewayApi.Instance.GetApplicationsAsync(true, true);
			return View();
		}

		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	
		public string GetAccesstoken()
		{

			authContext = new AuthenticationContext(authority);
			AuthenticationResult authResult = null;
			int retryCount = 0;
			bool retry = false;

			do
			{
				try
				{
					// ADAL includes an in memory cache, so this call will only send a message to the server if the cached token is expired.
					authResult = authContext.AcquireTokenAsync(apiResourceId, clientCredential).Result;
					Task<AuthenticationResult> task2 = Task<AuthenticationResult>.Factory.StartNew(() =>
					{
						return authResult;
					});
				}
				catch (AdalException ex)
				{
					if (ex.ErrorCode == "temporarily_unavailable")
					{
						retry = true;
						retryCount++;
					}
				}
			} while ((retry == true) && (retryCount < 3));

			return authResult.AccessToken;
/*

			HttpClient client = new HttpClient();

			client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authResult.AccessToken);

			HttpResponseMessage response = client.GetAsync(apiBaseAddress + "api/v1/users").Result;
			Task<HttpResponseMessage> task3 = Task<HttpResponseMessage>.Factory.StartNew(() =>
			{
				return response;
			});
			//HttpResponseMessage response = await client.GetAsync(apiBaseAddress + "api/Messages");
			string json = client.GetStringAsync(response.RequestMessage.RequestUri).Result;
			Task<string> task4 = Task<string>.Factory.StartNew(() =>
			{
				return json;
			});
			var objectToReturn = JsonConvert.DeserializeObject<UsersReturnType>(json);
			return authResult.AccessToken;*/
		}
	}
}
